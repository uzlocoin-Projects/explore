1.3.1 Release notes
====================

Uzlocoin Core version 1.3.1 is now available from:

  https://uzlocoin.io/

Please report bugs using the issue tracker at github:

  https://github.com/uzlocoinproject/uzlocoin/issues


How to Upgrade
--------------

If you are running an older version, shut it down. Wait until it has completely
shut down (which might take a few minutes for older versions), then run the
installer (on Windows) or just copy over /Applications/Uzlocoin-Qt (on Mac) or
uzlocoind/uzlocoin-qt (on Linux).


1.3.1 changelog
----------------

- Fix bug with DNS seeder


Credits
--------

- Julian Meyer

As well as the entire Bitcoin, Dash, and UZLOX teams!